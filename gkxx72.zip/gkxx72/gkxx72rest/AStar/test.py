import aStar
import time
startTime = time.time()

aStar.run()

print str(time.time() - startTime) + " seconds"
# for i in range(17):
# 	aStar.run(str(i))

# 12: 4
# 17: 7