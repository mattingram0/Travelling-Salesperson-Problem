class Vertex:

    def __init__(self, name, dist):
        self.name = name
        self.dist = dist
