import aStarDirty
import time
startTime = time.time()

aStarDirty.main()

print str(time.time() - startTime) + " seconds"
# for i in range(17):
# 	aStar.run(str(i))

# 12: 4
# 17: 7